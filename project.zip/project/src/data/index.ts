import { Feature, NavItem, PricingTier, Testimonial, FAQItem } from '../types';

export const navItems: NavItem[] = [
  { label: 'Features', href: '#features' },
  { label: 'Pricing', href: '#pricing' },
  { label: 'Testimonials', href: '#testimonials' },
  { label: 'FAQ', href: '#faq' },
  { label: 'Get Started', href: '#', isButton: true },
];

export const features: Feature[] = [
  {
    icon: 'LayoutDashboard',
    title: 'Intuitive Dashboard',
    description: 'Get a bird\'s-eye view of all your projects with our customizable dashboard that shows you what matters most.',
  },
  {
    icon: 'Timer',
    title: 'Time Tracking',
    description: 'Track time spent on tasks with our built-in timer. Perfect for billing clients or monitoring team productivity.',
  },
  {
    icon: 'MessageSquare',
    title: 'Team Collaboration',
    description: 'Communicate effectively with teammates through comments, @mentions, and real-time messaging.',
  },
  {
    icon: 'BarChart',
    title: 'Detailed Analytics',
    description: 'Make data-driven decisions with comprehensive reports and visualizations of your team\'s performance.',
  },
  {
    icon: 'Zap',
    title: 'Automation',
    description: 'Save time by automating repetitive tasks, notifications, and routine workflows.',
  },
  {
    icon: 'Shield',
    title: 'Enterprise Security',
    description: 'Rest easy with bank-level encryption, two-factor authentication, and regular security audits.',
  },
];

export const pricingTiers: PricingTier[] = [
  {
    name: 'Starter',
    price: '$9',
    description: 'Perfect for freelancers and solo entrepreneurs.',
    features: [
      'Up to 5 projects',
      'Basic analytics',
      'Email support',
      '1GB storage',
      'Limited integrations',
    ],
    buttonText: 'Start Free Trial',
  },
  {
    name: 'Professional',
    price: '$29',
    description: 'Great for small teams and growing businesses.',
    features: [
      'Unlimited projects',
      'Advanced analytics',
      'Priority support',
      '15GB storage',
      'All integrations',
      'Time tracking',
      'Custom fields',
    ],
    buttonText: 'Start Free Trial',
    isFeatured: true,
  },
  {
    name: 'Enterprise',
    price: '$99',
    description: 'For organizations requiring enhanced security and support.',
    features: [
      'Unlimited everything',
      'Dedicated account manager',
      'Custom onboarding',
      'Unlimited storage',
      'API access',
      'Custom integrations',
      'SSO authentication',
      'Compliance features',
    ],
    buttonText: 'Contact Sales',
  },
];

export const testimonials: Testimonial[] = [
  {
    quote: "Streamline has transformed how our team collaborates. We've reduced meeting time by 35% and increased productivity across the board.",
    author: "Sarah Johnson",
    role: "COO",
    company: "TechCorp",
    avatar: "https://images.pexels.com/photos/774909/pexels-photo-774909.jpeg?auto=compress&cs=tinysrgb&w=150"
  },
  {
    quote: "As a designer, having all my projects organized in one intuitive platform has been game-changing. I can't imagine working without it now.",
    author: "Michael Rodriguez",
    role: "Creative Director",
    company: "DesignStudio",
    avatar: "https://images.pexels.com/photos/220453/pexels-photo-220453.jpeg?auto=compress&cs=tinysrgb&w=150"
  },
  {
    quote: "The analytics features alone have paid for our subscription ten times over. We're making smarter decisions based on actual data.",
    author: "Jessica Chen",
    role: "Product Manager",
    company: "InnovateCo",
    avatar: "https://images.pexels.com/photos/415829/pexels-photo-415829.jpeg?auto=compress&cs=tinysrgb&w=150"
  },
];

export const faqItems: FAQItem[] = [
  {
    question: "How does the free trial work?",
    answer: "Our 14-day free trial gives you full access to all features of the Professional plan. No credit card required to sign up. At the end of your trial, you can choose the plan that works best for you or downgrade to our free plan with limited features."
  },
  {
    question: "Can I change plans later?",
    answer: "Absolutely! You can upgrade, downgrade, or cancel your plan at any time. If you upgrade, the new pricing will be prorated for the remainder of your billing cycle. If you downgrade, the new pricing will take effect at the start of your next billing cycle."
  },
  {
    question: "Is there a limit to how many team members I can add?",
    answer: "The Starter plan supports up to 3 team members. The Professional plan supports up to 10 team members. The Enterprise plan has unlimited team members. Additional team members can be added to any plan for an additional per-user fee."
  },
  {
    question: "Do you offer discounts for nonprofits or educational institutions?",
    answer: "Yes, we offer special pricing for nonprofit organizations, educational institutions, and open-source projects. Please contact our sales team for more information about our discount programs."
  },
  {
    question: "How secure is my data?",
    answer: "We take security seriously. All data is encrypted both in transit and at rest. We use industry-standard security practices, regular security audits, and provide two-factor authentication for all accounts. Our platform is compliant with GDPR, CCPA, and other privacy regulations."
  },
  {
    question: "What kind of support do you offer?",
    answer: "All plans include email support. Professional plans and above include priority email support with faster response times. Enterprise plans include a dedicated account manager and 24/7 phone support."
  }
];