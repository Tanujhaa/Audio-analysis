import React from 'react';
import { WeeklyReport as WeeklyReportType } from '../../types';
import { TrendingUp, TrendingDown } from 'lucide-react';

interface WeeklyReportProps {
  report: WeeklyReportType;
  previousReport?: WeeklyReportType;
}

const WeeklyReport: React.FC<WeeklyReportProps> = ({ report, previousReport }) => {
  const getScoreChange = (current: number, previous?: number) => {
    if (!previous) return null;
    return ((current - previous) / previous) * 100;
  };

  const ScoreCard = ({ 
    title, 
    score, 
    previousScore 
  }: { 
    title: string; 
    score: number; 
    previousScore?: number;
  }) => {
    const change = getScoreChange(score, previousScore);
    
    return (
      <div className="bg-white rounded-lg shadow p-6">
        <h3 className="text-sm font-medium text-gray-500">{title}</h3>
        <div className="mt-2 flex items-baseline">
          <p className="text-3xl font-semibold text-gray-900">
            {score.toFixed(1)}
          </p>
          <p className="ml-2 text-sm font-medium text-gray-500">/ 100</p>
        </div>
        
        {change !== null && (
          <div className={`mt-2 flex items-center text-sm ${
            change >= 0 ? 'text-green-600' : 'text-red-600'
          }`}>
            {change >= 0 ? (
              <TrendingUp className="h-4 w-4 mr-1" />
            ) : (
              <TrendingDown className="h-4 w-4 mr-1" />
            )}
            <span>{Math.abs(change).toFixed(1)}% from last week</span>
          </div>
        )}
      </div>
    );
  };

  return (
    <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
      <ScoreCard
        title="Average Speech Score"
        score={report.average_speech_score}
        previousScore={previousReport?.average_speech_score}
      />
      <ScoreCard
        title="Average Sentiment Score"
        score={report.average_sentiment_score}
        previousScore={previousReport?.average_sentiment_score}
      />
      <ScoreCard
        title="Average Engagement Score"
        score={report.average_engagement_score}
        previousScore={previousReport?.average_engagement_score}
      />
    </div>
  );
};

export default WeeklyReport;