import React, { useEffect, useState } from 'react';
import { supabase } from '../../lib/supabase';
import { AudioAnalysis, WeeklyReport as WeeklyReportType } from '../../types';
import AudioUpload from './AudioUpload';
import ScoresChart from './ScoresChart';
import WeeklyReport from './WeeklyReport';

const Dashboard: React.FC = () => {
  const [analyses, setAnalyses] = useState<AudioAnalysis[]>([]);
  const [currentReport, setCurrentReport] = useState<WeeklyReportType | null>(null);
  const [previousReport, setPreviousReport] = useState<WeeklyReportType | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');

  useEffect(() => {
    const fetchData = async () => {
      try {
        // Fetch audio analyses
        const { data: analysesData, error: analysesError } = await supabase
          .from('audio_analyses')
          .select('*')
          .order('created_at', { ascending: false })
          .limit(10);

        if (analysesError) throw analysesError;
        setAnalyses(analysesData);

        // Fetch weekly reports
        const { data: reportsData, error: reportsError } = await supabase
          .from('weekly_reports')
          .select('*')
          .order('week_start', { ascending: false })
          .limit(2);

        if (reportsError) throw reportsError;
        if (reportsData.length > 0) {
          setCurrentReport(reportsData[0]);
          if (reportsData.length > 1) {
            setPreviousReport(reportsData[1]);
          }
        }
      } catch (err: any) {
        setError(err.message);
      } finally {
        setLoading(false);
      }
    };

    fetchData();
  }, []);

  if (loading) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600"></div>
      </div>
    );
  }

  if (error) {
    return (
      <div className="p-4 bg-red-50 border border-red-200 text-red-600 rounded-md">
        {error}
      </div>
    );
  }

  return (
    <div className="container mx-auto px-4 py-8">
      <h1 className="text-2xl font-bold text-gray-900 mb-8">Dashboard</h1>
      
      <div className="grid grid-cols-1 gap-8">
        <AudioUpload />
        
        {currentReport && (
          <div className="space-y-4">
            <h2 className="text-xl font-semibold text-gray-900">Weekly Performance</h2>
            <WeeklyReport 
              report={currentReport} 
              previousReport={previousReport || undefined} 
            />
          </div>
        )}
        
        {analyses.length > 0 && (
          <div className="space-y-4">
            <h2 className="text-xl font-semibold text-gray-900">Recent Recordings</h2>
            <ScoresChart analyses={analyses} />
          </div>
        )}
      </div>
    </div>
  );
};

export default Dashboard;