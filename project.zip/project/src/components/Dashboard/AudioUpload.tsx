import React, { useState, useRef } from 'react';
import { Upload, Loader } from 'lucide-react';
import { supabase } from '../../lib/supabase';
import WaveSurfer from 'wavesurfer.js';

const AudioUpload: React.FC = () => {
  const [file, setFile] = useState<File | null>(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  const waveformRef = useRef<HTMLDivElement>(null);
  const wavesurfer = useRef<WaveSurfer | null>(null);

  const handleFileChange = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const selectedFile = e.target.files?.[0];
    if (selectedFile && selectedFile.type.startsWith('audio/')) {
      setFile(selectedFile);
      
      if (waveformRef.current) {
        wavesurfer.current?.destroy();
        wavesurfer.current = WaveSurfer.create({
          container: waveformRef.current,
          waveColor: '#4F46E5',
          progressColor: '#818CF8',
          cursorColor: '#4F46E5',
          barWidth: 2,
          barRadius: 3,
          cursorWidth: 1,
          height: 80,
          barGap: 3,
        });
        
        wavesurfer.current.loadBlob(selectedFile);
      }
    } else {
      setError('Please select a valid audio file');
    }
  };

  const handleUpload = async () => {
    if (!file) return;
    
    setLoading(true);
    setError('');

    try {
      const user = supabase.auth.getUser();
      if (!user) throw new Error('Not authenticated');

      // Upload to Supabase Storage
      const fileName = `${Date.now()}-${file.name}`;
      const { data: uploadData, error: uploadError } = await supabase.storage
        .from('audio-uploads')
        .upload(fileName, file);

      if (uploadError) throw uploadError;

      // Simulate ML analysis (replace with actual API call)
      const analysis = {
        speech_score: Math.random() * 100,
        sentiment_score: Math.random() * 100,
        engagement_score: Math.random() * 100,
      };

      // Save analysis results
      const { error: analysisError } = await supabase
        .from('audio_analyses')
        .insert([
          {
            audio_url: uploadData.path,
            speech_score: analysis.speech_score,
            sentiment_score: analysis.sentiment_score,
            engagement_score: analysis.engagement_score,
          },
        ]);

      if (analysisError) throw analysisError;

      setFile(null);
      if (wavesurfer.current) {
        wavesurfer.current.destroy();
        wavesurfer.current = null;
      }
    } catch (err: any) {
      setError(err.message);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="bg-white rounded-lg shadow p-6">
      <h2 className="text-xl font-semibold mb-4">Upload Audio Recording</h2>
      
      {error && (
        <div className="mb-4 bg-red-50 border border-red-200 text-red-600 px-4 py-3 rounded-md">
          {error}
        </div>
      )}

      <div className="mb-6">
        <label className="block text-sm font-medium text-gray-700 mb-2">
          Audio File
        </label>
        <div className="mt-1 flex justify-center px-6 pt-5 pb-6 border-2 border-gray-300 border-dashed rounded-md">
          <div className="space-y-1 text-center">
            <Upload className="mx-auto h-12 w-12 text-gray-400" />
            <div className="flex text-sm text-gray-600">
              <label className="relative cursor-pointer bg-white rounded-md font-medium text-blue-600 hover:text-blue-500 focus-within:outline-none focus-within:ring-2 focus-within:ring-offset-2 focus-within:ring-blue-500">
                <span>Upload a file</span>
                <input
                  type="file"
                  className="sr-only"
                  accept="audio/*"
                  onChange={handleFileChange}
                  disabled={loading}
                />
              </label>
              <p className="pl-1">or drag and drop</p>
            </div>
            <p className="text-xs text-gray-500">WAV, MP3 up to 10MB</p>
          </div>
        </div>
      </div>

      {file && (
        <>
          <div ref={waveformRef} className="mb-4" />
          <button
            onClick={handleUpload}
            disabled={loading}
            className="w-full flex justify-center py-2 px-4 border border-transparent rounded-md shadow-sm text-sm font-medium text-white bg-blue-600 hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500 disabled:opacity-50 disabled:cursor-not-allowed"
          >
            {loading ? (
              <>
                <Loader className="animate-spin -ml-1 mr-3 h-5 w-5 text-white" />
                Processing...
              </>
            ) : (
              'Analyze Recording'
            )}
          </button>
        </>
      )}
    </div>
  );
};

export default AudioUpload;