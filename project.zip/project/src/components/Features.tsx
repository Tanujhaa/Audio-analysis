import React from 'react';
import { Feature } from '../types';
import * as LucideIcons from 'lucide-react';

interface FeaturesProps {
  features: Feature[];
}

const Features: React.FC<FeaturesProps> = ({ features }) => {
  return (
    <section id="features" className="py-20 bg-white">
      <div className="container mx-auto px-4 md:px-6">
        <div className="text-center mb-16">
          <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-4">
            Everything you need to succeed
          </h2>
          <p className="text-lg text-gray-600 max-w-2xl mx-auto">
            Our comprehensive platform provides all the tools your team needs to stay organized, 
            collaborate effectively, and deliver projects on time.
          </p>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {features.map((feature, index) => {
            // Dynamically get icon from Lucide
            const IconComponent = LucideIcons[feature.icon as keyof typeof LucideIcons];
            
            return (
              <div 
                key={index} 
                className="bg-white p-6 rounded-xl border border-gray-100 shadow-sm hover:shadow-md transition-shadow duration-300"
              >
                <div className="w-12 h-12 rounded-lg bg-blue-100 flex items-center justify-center mb-6">
                  {IconComponent && <IconComponent className="text-blue-600" size={24} />}
                </div>
                <h3 className="text-xl font-semibold text-gray-900 mb-3">{feature.title}</h3>
                <p className="text-gray-600">{feature.description}</p>
              </div>
            );
          })}
        </div>
        
        <div className="mt-16 text-center">
          <a 
            href="#" 
            className="inline-flex items-center text-blue-600 font-semibold hover:text-blue-700 transition-colors duration-300"
          >
            Explore all features
            <LucideIcons.ArrowRight className="ml-2" size={16} />
          </a>
        </div>
      </div>
    </section>
  );
};

export default Features;