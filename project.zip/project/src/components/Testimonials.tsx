import React, { useState, useEffect } from 'react';
import { ChevronLeft, ChevronRight } from 'lucide-react';
import { Testimonial } from '../types';

interface TestimonialsProps {
  testimonials: Testimonial[];
}

const Testimonials: React.FC<TestimonialsProps> = ({ testimonials }) => {
  const [currentIndex, setCurrentIndex] = useState(0);
  const [isAnimating, setIsAnimating] = useState(false);

  const nextSlide = () => {
    if (isAnimating) return;
    setIsAnimating(true);
    setCurrentIndex((prevIndex) => (prevIndex + 1) % testimonials.length);
  };

  const prevSlide = () => {
    if (isAnimating) return;
    setIsAnimating(true);
    setCurrentIndex((prevIndex) => 
      prevIndex === 0 ? testimonials.length - 1 : prevIndex - 1
    );
  };

  useEffect(() => {
    // Reset animation flag after transition
    const timer = setTimeout(() => {
      setIsAnimating(false);
    }, 500);
    
    return () => clearTimeout(timer);
  }, [currentIndex]);

  // Auto-rotate testimonials
  useEffect(() => {
    const interval = setInterval(() => {
      nextSlide();
    }, 6000);
    
    return () => clearInterval(interval);
  }, [currentIndex]);

  return (
    <section id="testimonials" className="py-20 bg-gradient-to-br from-indigo-50 to-blue-50">
      <div className="container mx-auto px-4 md:px-6">
        <div className="text-center mb-16">
          <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-4">
            Loved by teams worldwide
          </h2>
          <p className="text-lg text-gray-600 max-w-2xl mx-auto">
            Don't just take our word for it. See what our customers have to say about Streamline.
          </p>
        </div>
        
        <div className="relative max-w-4xl mx-auto">
          <div className="overflow-hidden rounded-xl">
            <div 
              className="flex transition-transform duration-500 ease-in-out"
              style={{ transform: `translateX(-${currentIndex * 100}%)` }}
            >
              {testimonials.map((testimonial, index) => (
                <div 
                  key={index} 
                  className="w-full flex-shrink-0 px-4 md:px-12 py-8 md:py-12 bg-white rounded-xl shadow-sm"
                >
                  <div className="flex flex-col md:flex-row items-center md:items-start gap-6 md:gap-8">
                    <div className="md:w-1/4 flex justify-center">
                      <img 
                        src={testimonial.avatar} 
                        alt={testimonial.author} 
                        className="w-20 h-20 rounded-full border-2 border-blue-100"
                      />
                    </div>
                    <div className="md:w-3/4">
                      <div className="mb-6">
                        <svg width="120" height="30" viewBox="0 0 120 30" fill="none" xmlns="http://www.w3.org/2000/svg">
                          <path d="M12 4L14.5 9L20 10L16 14L17 20L12 17L7 20L8 14L4 10L9.5 9L12 4Z" fill="#FBBF24" />
                          <path d="M36 4L38.5 9L44 10L40 14L41 20L36 17L31 20L32 14L28 10L33.5 9L36 4Z" fill="#FBBF24" />
                          <path d="M60 4L62.5 9L68 10L64 14L65 20L60 17L55 20L56 14L52 10L57.5 9L60 4Z" fill="#FBBF24" />
                          <path d="M84 4L86.5 9L92 10L88 14L89 20L84 17L79 20L80 14L76 10L81.5 9L84 4Z" fill="#FBBF24" />
                          <path d="M108 4L110.5 9L116 10L112 14L113 20L108 17L103 20L104 14L100 10L105.5 9L108 4Z" fill="#FBBF24" />
                        </svg>
                      </div>
                      <p className="text-gray-700 text-lg mb-6 italic">"{testimonial.quote}"</p>
                      <div>
                        <p className="font-semibold text-gray-900">{testimonial.author}</p>
                        <p className="text-gray-600">{testimonial.role}, {testimonial.company}</p>
                      </div>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>
          
          <button 
            className="absolute left-0 top-1/2 -translate-y-1/2 -translate-x-1/2 bg-white rounded-full p-2 shadow-md text-gray-700 hover:text-blue-600 focus:outline-none"
            onClick={prevSlide}
            disabled={isAnimating}
          >
            <ChevronLeft size={24} />
          </button>
          <button 
            className="absolute right-0 top-1/2 -translate-y-1/2 translate-x-1/2 bg-white rounded-full p-2 shadow-md text-gray-700 hover:text-blue-600 focus:outline-none"
            onClick={nextSlide}
            disabled={isAnimating}
          >
            <ChevronRight size={24} />
          </button>
          
          <div className="flex justify-center mt-8 space-x-2">
            {testimonials.map((_, index) => (
              <button
                key={index}
                className={`h-2 rounded-full transition-all duration-300 ${
                  currentIndex === index ? 'w-6 bg-blue-600' : 'w-2 bg-gray-300'
                }`}
                onClick={() => {
                  if (!isAnimating) {
                    setIsAnimating(true);
                    setCurrentIndex(index);
                  }
                }}
                aria-label={`Go to slide ${index + 1}`}
              />
            ))}
          </div>
        </div>
        
        <div className="mt-16 flex flex-wrap justify-center gap-8 md:gap-16">
          <div className="text-gray-400">
            <svg width="120" height="40" viewBox="0 0 120 40" className="h-8">
              <text x="0" y="25" fill="currentColor" className="font-bold text-lg">TECHCORP</text>
            </svg>
          </div>
          <div className="text-gray-400">
            <svg width="120" height="40" viewBox="0 0 120 40" className="h-8">
              <text x="0" y="25" fill="currentColor" className="font-bold text-lg">DesignStudio</text>
            </svg>
          </div>
          <div className="text-gray-400">
            <svg width="120" height="40" viewBox="0 0 120 40" className="h-8">
              <text x="0" y="25" fill="currentColor" className="font-bold text-lg">InnovateCo</text>
            </svg>
          </div>
          <div className="text-gray-400">
            <svg width="120" height="40" viewBox="0 0 120 40" className="h-8">
              <text x="0" y="25" fill="currentColor" className="font-bold text-lg">GrowthLabs</text>
            </svg>
          </div>
        </div>
      </div>
    </section>
  );
};

export default Testimonials;