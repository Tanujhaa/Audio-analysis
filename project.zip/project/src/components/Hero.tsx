import React from 'react';
import { ArrowRight } from 'lucide-react';

const Hero: React.FC = () => {
  return (
    <section className="pt-28 pb-20 md:pt-36 md:pb-32 bg-gradient-to-br from-blue-50 to-indigo-50">
      <div className="container mx-auto px-4 md:px-6">
        <div className="flex flex-col md:flex-row items-center">
          <div className="md:w-1/2 mb-12 md:mb-0">
            <h1 className="text-4xl md:text-5xl lg:text-6xl font-bold text-gray-900 leading-tight mb-6">
              <span className="block">Streamline your</span>
              <span className="text-blue-600">workflow</span>
              <span className="block">boost productivity</span>
            </h1>
            
            <p className="text-lg md:text-xl text-gray-600 mb-8 max-w-lg">
              The all-in-one platform that helps teams collaborate, track projects, and deliver results faster than ever before.
            </p>
            
            <div className="flex flex-col sm:flex-row gap-4">
              <a 
                href="#" 
                className="px-8 py-3 bg-blue-600 text-white font-semibold rounded-lg hover:bg-blue-700 transition-colors duration-300 flex items-center justify-center group"
              >
                Get Started 
                <ArrowRight className="ml-2 group-hover:translate-x-1 transition-transform duration-300" size={18} />
              </a>
              <a 
                href="#" 
                className="px-8 py-3 bg-white text-blue-600 font-semibold rounded-lg border border-blue-200 hover:border-blue-400 transition-colors duration-300 flex items-center justify-center"
              >
                Watch Demo
              </a>
            </div>
            
            <div className="mt-8 flex items-center">
              <div className="flex -space-x-2">
                <img 
                  src="https://images.pexels.com/photos/415829/pexels-photo-415829.jpeg?auto=compress&cs=tinysrgb&w=150" 
                  alt="User" 
                  className="w-8 h-8 rounded-full border-2 border-white"
                />
                <img 
                  src="https://images.pexels.com/photos/774909/pexels-photo-774909.jpeg?auto=compress&cs=tinysrgb&w=150" 
                  alt="User" 
                  className="w-8 h-8 rounded-full border-2 border-white"
                />
                <img 
                  src="https://images.pexels.com/photos/220453/pexels-photo-220453.jpeg?auto=compress&cs=tinysrgb&w=150" 
                  alt="User" 
                  className="w-8 h-8 rounded-full border-2 border-white"
                />
              </div>
              <p className="ml-4 text-sm text-gray-600">
                <span className="font-semibold">2,500+</span> teams already using Streamline
              </p>
            </div>
          </div>
          
          <div className="md:w-1/2 relative">
            <div className="rounded-xl bg-white shadow-xl overflow-hidden p-2 md:p-4 transform rotate-1 hover:rotate-0 transition-transform duration-300">
              <img 
                src="https://images.pexels.com/photos/3182775/pexels-photo-3182775.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750"
                alt="Dashboard Preview" 
                className="rounded-lg"
              />
            </div>
            <div className="absolute -bottom-4 -left-4 h-24 w-24 bg-purple-500 rounded-full opacity-20 animate-pulse"></div>
            <div className="absolute -top-4 -right-4 h-16 w-16 bg-blue-500 rounded-full opacity-20 animate-pulse" style={{animationDelay: '1s'}}></div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default Hero;