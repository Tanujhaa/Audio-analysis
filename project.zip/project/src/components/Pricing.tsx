import React from 'react';
import { Check, X } from 'lucide-react';
import { PricingTier } from '../types';

interface PricingProps {
  tiers: PricingTier[];
}

const Pricing: React.FC<PricingProps> = ({ tiers }) => {
  return (
    <section id="pricing" className="py-20 bg-gray-50">
      <div className="container mx-auto px-4 md:px-6">
        <div className="text-center mb-16">
          <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-4">
            Simple, transparent pricing
          </h2>
          <p className="text-lg text-gray-600 max-w-2xl mx-auto">
            Choose the plan that works best for you and your team. 
            All plans include a 14-day free trial.
          </p>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8 max-w-6xl mx-auto">
          {tiers.map((tier, index) => (
            <div 
              key={index}
              className={`bg-white rounded-xl border ${
                tier.isFeatured 
                  ? 'border-blue-200 shadow-lg relative -mt-4'
                  : 'border-gray-200 shadow-sm'
              } overflow-hidden transition-all duration-300 hover:shadow-lg`}
            >
              {tier.isFeatured && (
                <div className="bg-blue-600 text-white text-sm font-semibold py-1 px-3 text-center">
                  Most Popular
                </div>
              )}
              
              <div className="p-6 md:p-8">
                <h3 className="text-2xl font-bold text-gray-900">{tier.name}</h3>
                <div className="mt-4 flex items-baseline">
                  <span className="text-4xl font-bold text-gray-900">{tier.price}</span>
                  <span className="ml-1 text-gray-500">/month</span>
                </div>
                <p className="mt-4 text-gray-600">{tier.description}</p>
                
                <ul className="mt-6 space-y-4">
                  {tier.features.map((feature, i) => (
                    <li key={i} className="flex items-start">
                      <Check className="h-5 w-5 text-green-500 mt-0.5 flex-shrink-0" />
                      <span className="ml-3 text-gray-600">{feature}</span>
                    </li>
                  ))}
                </ul>
                
                <div className="mt-8">
                  <a
                    href="#"
                    className={`w-full block text-center py-3 px-6 rounded-lg font-semibold transition-colors duration-300 ${
                      tier.isFeatured
                        ? 'bg-blue-600 text-white hover:bg-blue-700'
                        : 'bg-gray-100 text-gray-800 hover:bg-gray-200'
                    }`}
                  >
                    {tier.buttonText}
                  </a>
                </div>
              </div>
            </div>
          ))}
        </div>
        
        <div className="mt-12 text-center text-gray-600">
          <p>All plans include 24/7 support, 99.9% uptime guarantee, and regular updates.</p>
          <p className="mt-2">
            <a href="#" className="text-blue-600 font-medium hover:underline">
              View full pricing details
            </a>
          </p>
        </div>
      </div>
    </section>
  );
};

export default Pricing;