export interface User {
  id: string;
  email: string;
  full_name: string;
  department: string;
  created_at: string;
}

export interface AudioAnalysis {
  id: string;
  user_id: string;
  audio_url: string;
  speech_score: number;
  sentiment_score: number;
  engagement_score: number;
  created_at: string;
}

export interface WeeklyReport {
  week_start: string;
  week_end: string;
  average_speech_score: number;
  average_sentiment_score: number;
  average_engagement_score: number;
}