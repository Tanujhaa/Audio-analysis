/*
  # Initial Schema Setup for VoiceMetrics Pro

  1. Tables
    - staff_profiles
      - User profile information including department
    - audio_analyses
      - Stores audio analysis results and metadata
    - weekly_reports
      - Aggregated weekly performance metrics

  2. Security
    - RLS policies for data access
    - Authentication required for all operations
*/

-- Create staff_profiles table
CREATE TABLE staff_profiles (
  id uuid PRIMARY KEY REFERENCES auth.users(id),
  full_name text NOT NULL,
  email text UNIQUE NOT NULL,
  department text NOT NULL,
  created_at timestamptz DEFAULT now()
);

-- Create audio_analyses table
CREATE TABLE audio_analyses (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid REFERENCES staff_profiles(id) NOT NULL,
  audio_url text NOT NULL,
  speech_score float NOT NULL,
  sentiment_score float NOT NULL,
  engagement_score float NOT NULL,
  created_at timestamptz DEFAULT now()
);

-- Create weekly_reports table
CREATE TABLE weekly_reports (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid REFERENCES staff_profiles(id) NOT NULL,
  week_start date NOT NULL,
  week_end date NOT NULL,
  average_speech_score float NOT NULL,
  average_sentiment_score float NOT NULL,
  average_engagement_score float NOT NULL,
  created_at timestamptz DEFAULT now()
);

-- Enable RLS
ALTER TABLE staff_profiles ENABLE ROW LEVEL SECURITY;
ALTER TABLE audio_analyses ENABLE ROW LEVEL SECURITY;
ALTER TABLE weekly_reports ENABLE ROW LEVEL SECURITY;

-- Create policies
CREATE POLICY "Users can view own profile"
  ON staff_profiles
  FOR SELECT
  TO authenticated
  USING (auth.uid() = id);

CREATE POLICY "Users can update own profile"
  ON staff_profiles
  FOR UPDATE
  TO authenticated
  USING (auth.uid() = id);

CREATE POLICY "Users can view own audio analyses"
  ON audio_analyses
  FOR SELECT
  TO authenticated
  USING (auth.uid() = user_id);

CREATE POLICY "Users can create own audio analyses"
  ON audio_analyses
  FOR INSERT
  TO authenticated
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can view own weekly reports"
  ON weekly_reports
  FOR SELECT
  TO authenticated
  USING (auth.uid() = user_id);